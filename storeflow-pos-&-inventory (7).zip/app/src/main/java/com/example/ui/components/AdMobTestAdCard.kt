package com.example.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

const val PRODUCTION_ADMOB_APP_ID = "ca-app-pub-8022103414024000~6845102107"
const val PRODUCTION_ADMOB_AD_UNIT_ID = "ca-app-pub-8022103414024000/3066295738"
const val DEFAULT_TEST_NATIVE_AD_UNIT_ID = PRODUCTION_ADMOB_AD_UNIT_ID

@Composable
fun AdMobTestNativeAdCard(
    adUnitId: String = PRODUCTION_ADMOB_AD_UNIT_ID,
    modifier: Modifier = Modifier
) {
    if (LocalInspectionMode.current) return

    val context = LocalContext.current
    val resolvedUnitId = remember(adUnitId) {
        val trimmed = adUnitId.trim()
        if (trimmed.isBlank() || trimmed.contains("3940256099942544")) {
            PRODUCTION_ADMOB_AD_UNIT_ID
        } else {
            trimmed
        }
    }

    val adView = remember(context, resolvedUnitId) {
        AdView(context).apply {
            setAdSize(AdSize.BANNER)
            this.adUnitId = resolvedUnitId
            loadAd(AdRequest.Builder().build())
        }
    }

    DisposableEffect(adView) {
        onDispose {
            adView.destroy()
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .testTag("admob_test_ad_card"),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            factory = { adView },
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
        )
    }
}

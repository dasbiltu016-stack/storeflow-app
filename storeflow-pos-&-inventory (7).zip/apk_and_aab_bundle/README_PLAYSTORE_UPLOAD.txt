====================================================================
STOREFLOW POS & INVENTORY - GOOGLE PLAY STORE & APK PACKAGE (v1.0.2)
====================================================================

App Name:        StoreFlow POS & Inventory
Package Name:    com.aistudio.storeflow.kxpqmr
Version Code:    3
Version Name:    1.0.2
Min SDK:         24 (Android 7.0+)
Target SDK:      36 (Android 16 / Google Play Compliant)

AdMob App ID:    ca-app-pub-8022103414024000~6845102107
AdMob Unit ID:   ca-app-pub-8022103414024000/3066295738
AdMob SDK:       com.google.android.gms:play-services-ads (Real AdView)

PIN Security:    Default 1234 (Disabled by default; no PIN shown on
                 Home Page. Users can enable/set PIN in Settings.)

--------------------------------------------------------------------
FILES INCLUDED IN THIS FOLDER (apk_and_aab_bundle):
--------------------------------------------------------------------
1. StoreFlow_POS_PlayStore_Release.aab
   -> Signed Production Android App Bundle (.aab) ready to upload
      directly to Google Play Console.

2. StoreFlow_POS_Release.apk
   -> Signed Production APK ready to install directly on any Android
      phone or tablet.

3. StoreFlow_POS_Installable.apk
   -> Debug APK for quick testing on Android phones.
